# Tasks - Work

## In Progress


## To Do

- [ ] Analyze the collected logs to identify any patterns in error frequency and severity over the past 7 days.
- [ ] Create a script to automate the daily log collection and filtering process for the 4am window.
- [ ] Investigate whether the errors are related to specific plugins or software versions.
- [ ] Evaluate the impact of scheduled tasks running at 4am on the system stability.
- [ ] Document the findings in a structured format with clear recommendations for immediate action and long-term prevention.
- [ ] --

## Backlog


## Done


## ✨ 核心原则

- [ ] **专注深度工作**：每天安排 2-3 小时无干扰时段
- [ ] **二八法则**：80% 成果来自 20% 关键任务
- [ ] **原子化任务**：将大项目拆解为 ≤30 分钟可完成的小单元
- [ ] **能量管理 > 时间管理**：在高效时段处理高难度任务
