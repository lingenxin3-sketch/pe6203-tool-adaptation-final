# Tasks - Work

## In Progress

- [ ] Analyze the existing Ableton log files to identify common error patterns such as syntax errors, crash reports, or resource allocation failures.
- [ ] Define a clear data schema for parsed logs with field names, types, and descriptions (e.g., error_type, timestamp, severity, message, stack_trace).
- [ ] Identify key metadata fields that must be extracted from the log files (e.g., device name, session ID, error code).
- [ ] Validate the schema against sample log entries to ensure completeness and accuracy.
- [ ] Document the parsing logic and error handling mechanisms for edge cases (e.g., malformed logs, missing fields).

## To Do

- [ ] --

## Backlog


## Done


## ✨ 核心原则

- [ ] **专注深度工作**：每天安排 2-3 小时无干扰时段
- [ ] **二八法则**：80% 成果来自 20% 关键任务
- [ ] **原子化任务**：将大项目拆解为 ≤30 分钟可完成的小单元
- [ ] **能量管理 > 时间管理**：在高效时段处理高难度任务
