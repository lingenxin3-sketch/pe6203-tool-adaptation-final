# Tasks - Work

## In Progress

- [ ] --

## To Do

- [ ] Verify if Ableton error logs are available in the provided file system

## Backlog


## Done


## ✨ 核心原则

- [ ] **专注深度工作**：每天安排 2-3 小时无干扰时段
- [ ] **二八法则**：80% 成果来自 20% 关键任务
- [ ] **原子化任务**：将大项目拆解为 ≤30 分钟可完成的小单元
- [ ] **能量管理 > 时间管理**：在高效时段处理高难度任务
